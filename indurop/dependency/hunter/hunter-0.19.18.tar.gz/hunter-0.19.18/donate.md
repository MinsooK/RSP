Donations
=========

If you like this project and it's goals consider supporting it by making a donation.

[![Donate][2]][1]

[![Gratipay](https://img.shields.io/gratipay/Hunter.svg?style=social&label=donate)](https://www.gratipay.com/Hunter/)

Sberbank of Russia:
* 5469 3800 3946 0992 (USD)
* 5469 3800 2768 7895 (RUB)

Also https://www.bountysource.com/ can be used to open a bounty for the exact problem. For such issues badge [bounty](https://github.com/ruslo/hunter/issues?q=is%3Aopen+is%3Aissue+label%3Abounty) will be added automatically.

Thanks! :)

[1]: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UN8PDZZ3Q7VVL
[2]: https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif
