#include <cpp_redis/cpp_redis>

int main() {
}
