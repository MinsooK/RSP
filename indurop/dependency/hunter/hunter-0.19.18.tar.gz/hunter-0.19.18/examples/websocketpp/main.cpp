
#include <iostream>
#include <websocketpp/version.hpp>

int main(int argc, char** argv)
{
    std::cout << websocketpp::user_agent << std::endl;
    return 0;
}
