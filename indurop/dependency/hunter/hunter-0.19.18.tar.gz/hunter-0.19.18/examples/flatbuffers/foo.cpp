#include <flatbuffers/flatbuffers.h>

int main() {
}
