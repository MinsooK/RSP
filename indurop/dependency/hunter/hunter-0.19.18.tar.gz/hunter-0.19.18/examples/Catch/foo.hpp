#ifndef FOO_H
#define FOO_H
#pragma once

namespace ns_foo {
    bool return_true();
}

#endif
