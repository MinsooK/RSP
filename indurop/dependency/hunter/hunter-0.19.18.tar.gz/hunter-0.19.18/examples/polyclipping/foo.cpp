// Example was simplified since tested on different incompatible versions

#include <polyclipping/clipper.hpp>

int main() {
}
