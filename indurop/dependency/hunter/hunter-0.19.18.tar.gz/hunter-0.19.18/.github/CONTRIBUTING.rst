Please read `contributing guide <https://github.com/ruslo/hunter/wiki/dev.contribution>`__ before sending pull requests.

Thanks.
