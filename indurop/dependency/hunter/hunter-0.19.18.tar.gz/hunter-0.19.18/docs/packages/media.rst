Media
-----

 * `Jpeg <https://github.com/ruslo/hunter/wiki/pkg.jpeg>`_ -  library for JPEG image compression.
 * `libyuv <https://github.com/ruslo/hunter/wiki/pkg.libyuv>`_ - YUV scaling and conversion functionality.
 * `PNG <https://github.com/ruslo/hunter/wiki/pkg.png>`_ - library for use in applications that read, create, and manipulate PNG (Portable Network Graphics>`_ raster image files.
 * `TIFF <https://github.com/ruslo/hunter/wiki/pkg.tiff>`_
