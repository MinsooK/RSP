Misc
----

 * `convertutf <https://github.com/ruslo/hunter/wiki/pkg.convertutf>`_
 * `IntSizeof <https://github.com/ruslo/hunter/wiki/pkg.intsizeof>`_
 * `Sugar <https://github.com/ruslo/hunter/wiki/pkg.sugar>`_ - CMake tools and examples: collecting source files, warnings suppression, etc.
 * `Leathers <https://github.com/ruslo/hunter/wiki/pkg.leathers>`_ - Warning suppression library (C++>`_ 
