Scripting
---------

 * `Lua <https://github.com/ruslo/hunter/wiki/pkg.lua>`_ - powerful, efficient, lightweight, embeddable scripting language.

