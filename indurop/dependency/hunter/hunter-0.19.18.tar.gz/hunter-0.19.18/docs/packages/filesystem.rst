.. spelling::

  Filesystem

Filesystem
----------

 * `fmt <https://github.com/ruslo/hunter/wiki/pkg.fmt>`_ - Small, safe and fast formatting library
 * `hdf5 <https://github.com/ruslo/hunter/wiki/pkg.hdf5>`_ -  data model, library, and file format for storing and managing data.
 * `tinydir <https://github.com/ruslo/hunter/wiki/pkg.tinydir>`_ - Lightweight, portable and easy to integrate C directory and file reader
