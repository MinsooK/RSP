OS
--

 * `Android-Apk <https://github.com/ruslo/hunter/wiki/pkg.android.apk>`_
 * `Android-Modules <https://github.com/ruslo/hunter/wiki/pkg.android.modules>`_
 * `Android-SDK <https://github.com/ruslo/hunter/wiki/pkg.android.sdk>`_
 * `ios_sim <https://github.com/ruslo/hunter/wiki/pkg.ios_sim>`_
 * `Qt-Android-CMake <https://github.com/ruslo/hunter/wiki/pkg.qt.android.cmake>`_
 * `Washer <https://github.com/ruslo/hunter/wiki/pkg.washer>`_ - Lightweight, header-only, C++ wrapper around the Windows API
 * `WTL <https://github.com/ruslo/hunter/wiki/pkg.wtl>`_ - Windows Template Library (WTL>`_ is a C++ library for developing Windows applications and UI components.
