Frameworks
----------

 * `Boost <https://github.com/ruslo/hunter/wiki/pkg.boost>`_ - peer-reviewed portable C++ source libraries.
 * `Boost.process <https://github.com/ruslo/hunter/wiki/pkg.boost.process>`_
 * `Qt <https://github.com/ruslo/hunter/wiki/pkg.qt>`_
 * `QtQmlManager <https://github.com/ruslo/hunter/wiki/pkg.qt.qml.manager>`_
 * `wxWidgets <https://github.com/ruslo/hunter/wiki/pkg.wxwidgets>`_ - Cross-Platform GUI Library
