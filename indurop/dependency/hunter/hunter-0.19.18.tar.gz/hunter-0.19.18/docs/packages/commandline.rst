.. spelling::

  Commandline
  commandline

Commandline Tools
-----------------

 * `gflags <https://github.com/ruslo/hunter/wiki/pkg.gflags>`__ - contains a C++ library that implements commandline flags processing
 * `cxxopts <https://github.com/ruslo/hunter/wiki/pkg.cxxopts>`__ - Lightweight C++ command line option parser
