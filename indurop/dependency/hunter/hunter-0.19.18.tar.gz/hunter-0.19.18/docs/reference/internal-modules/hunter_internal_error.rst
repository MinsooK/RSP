.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

hunter_internal_error
---------------------

Wrapper for the ``message(FATAL_ERROR ...)``. Some internal unrecoverable error.
