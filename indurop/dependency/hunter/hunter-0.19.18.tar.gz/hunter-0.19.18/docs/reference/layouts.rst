.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Layouts
-------

.. toctree::
   :maxdepth: 1

   /reference/layouts/sources
   /reference/layouts/deployed
