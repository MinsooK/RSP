
#include <iostream>

#include <monitor.h>


extern "C" void run()
{
    std::cout << test::time << std::endl;
}


