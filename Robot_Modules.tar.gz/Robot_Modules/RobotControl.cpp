#include <monitor.h>


extern "C" void run()
{
   test::time = test::time + 1;
}